import base64
import os, sys
from janob_darknet import code
janob_darknet = input("""
image encode 

1) encode
2) decode
3) delete 
: """)

#decode

if janob_darknet=="2":  
	file = open(code.joylashuv_txt, 'rb')
	byte = file.read()
	file.close()
	print("shifrdan chiqarildi")
	decodeit = open(code.image_name, 'wb')
	decodeit.write(base64.b64decode((byte)))
	decodeit.close()
	
# encode	

elif janob_darknet == "1":	
	with open(code.joylashuv_jpg, "rb") as image2string:
		
		converted_string = base64.b64encode(image2string.read())
		print("shifrlandi")
			  
	with open(code.txt_name, "wb") as file:
	    file.write(converted_string)
	    
# delete

elif janob_darknet == "3":
	os.system("rm -rf "+ code.file_for_delete)
	print("file ochirildi")
else:
	print("hato(")