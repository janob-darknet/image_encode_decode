#encode .txt file joylashuvi
joylashuv_txt = '/storage/emulated/0/image_encoder/janob_darknet.txt'
#decode .jpg file joylashuvi
joylashuv_jpg = '/storage/emulated/0/image_encoder/janob_darknet.jpg'
# .jpg hamda .txt fileni delete qilish uchun
file_for_delete = "test.py"
# rasm nomi: exemple.jpg
image_name = "janob.jpg"
# text file .txt file nomi
txt_name = "darknet.txt"